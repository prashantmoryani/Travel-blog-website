from django.contrib import admin
from .models import Tour

admin.site.register(Tour)
